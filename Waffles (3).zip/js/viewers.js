function toggleFullscreen() {
            const iframe = document.getElementById('game-iframe');
            if (iframe.requestFullscreen) {
                iframe.requestFullscreen();
            } else if (iframe.mozRequestFullScreen) {
                iframe.mozRequestFullScreen();
            } else if (iframe.webkitRequestFullscreen) {
                iframe.webkitRequestFullscreen();
            } else if (iframe.msRequestFullscreen) {
                iframe.msRequestFullscreen();
            }
        }

        function reloadIframe() {
            const iframe = document.getElementById('game-iframe');
            iframe.src = iframe.src;
        }

        function goHome() {
            window.location.href = '/games';
        }
        /*function showAd() {
            const iframe = document.getElementById('game-iframe');
// Set the original URL
    const originalUrl = iframe.src;
    // Set the URL to redirect to
    const redirectUrl = "/file";
    // Set the time to stay on the redirect URL (in milliseconds)
    const redirectTime = 5000; // 5 seconds

    // Redirect the iframe to the new URL
    function redirectIframe() {
        iframe.src = redirectUrl;
        
        // After the specified time, redirect back to the original URL
        setTimeout(() => {
            iframe.src = originalUrl;
        }, redirectTime);
    }

    // Call the function to perform the redirection
    redirectIframe();
        }
        
showAd();